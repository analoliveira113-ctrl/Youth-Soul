import React, { useState } from "react";
import { supabase } from "../services/supabase";

export default function ApoioAosJovens() {
  const [formulario, setFormulario] = useState({
    nome: "",
    idade: "",
    cidade: "",
    contato: "",
    interesse: "",
    mensagem: "",
    consentimento: false
  });

  const [enviando, setEnviando] = useState(false);
  const [status, setStatus] = useState("");
  const [erro, setErro] = useState(false);

  function atualizarCampo(event) {
    const { name, value, checked, type } = event.target;

    setFormulario((anterior) => ({
      ...anterior,
      [name]: type === "checkbox" ? checked : value
    }));
  }

  async function registrarSolicitacao(event) {
    event.preventDefault();

    if (!formulario.consentimento) {
      setErro(true);
      setStatus("Você precisa aceitar o consentimento para continuar.");
      return;
    }

    setEnviando(true);
    setStatus("");
    setErro(false);

    const { error } = await supabase
      .from("solicitacoes_apoio")
      .insert([
        {
          nome: formulario.nome,
          idade: Number(formulario.idade),
          cidade: formulario.cidade,
          contato: formulario.contato,
          interesse: formulario.interesse,
          mensagem: formulario.mensagem,
          consentimento: true
        }
      ]);

    setEnviando(false);

    if (error) {
      console.error("Erro ao enviar solicitação:", error);
      setErro(true);
      setStatus("Não foi possível enviar. Verifique os dados e tente novamente.");
      return;
    }

    setStatus("Solicitação enviada com sucesso! Obrigada por confiar na Youth Soul.");

    setFormulario({
      nome: "",
      idade: "",
      cidade: "",
      contato: "",
      interesse: "",
      mensagem: "",
      consentimento: false
    });
  }

  return (
    <main className="apoio-page">
      <section className="apoio-hero">
        <span className="apoio-etiqueta">VOCÊ NÃO ESTÁ SOZINHO</span>

        <h1>
          Seu futuro começa com uma <span>oportunidade.</span>
        </h1>

        <p>
          A Youth Soul acredita no potencial de cada jovem.
          Estamos aqui para ouvir, orientar e conectar você a novas possibilidades.
        </p>

        <a href="#formulario-apoio" className="apoio-botao">
          Quero receber apoio →
        </a>
      </section>

      <section className="apoio-introducao">
        <span className="apoio-etiqueta">NOSSO PROPÓSITO</span>
        <h2>Um espaço para crescer, aprender e sonhar</h2>

        <p>
          Sabemos que cada trajetória é única. Por isso, queremos conhecer
          sua história e entender quais oportunidades podem fazer sentido
          para você.
        </p>
      </section>

      <section className="apoio-oportunidades">
        <article className="apoio-card">
          <span>📚</span>
          <h3>Educação e aprendizado</h3>
          <p>
            Descubra caminhos para desenvolver habilidades e ampliar seus conhecimentos.
          </p>
        </article>

        <article className="apoio-card">
          <span>💼</span>
          <h3>Oportunidades profissionais</h3>
          <p>
            Conheça possibilidades de desenvolvimento e preparação para o mundo do trabalho.
          </p>
        </article>

        <article className="apoio-card">
          <span>🤝</span>
          <h3>Conexões e orientação</h3>
          <p>
            Compartilhe seus interesses e conheça possibilidades de apoio e orientação.
          </p>
        </article>
      </section>

      <section className="apoio-acolhimento">
        <div>
          <span className="apoio-etiqueta">CADA HISTÓRIA IMPORTA</span>
          <h2>Queremos conhecer você!</h2>
          <p>
            Não existe uma única maneira de construir o futuro.
            Conte um pouco sobre o que você procura e quais são seus objetivos.
          </p>
        </div>

        <div className="apoio-destaque">
          <span>💛</span>
          <h3>Você tem potencial.</h3>
          <p>
            Pequenos passos também fazem parte de grandes conquistas.
          </p>
        </div>
      </section>

      <section className="apoio-formulario" id="formulario-apoio">
        <div className="apoio-formulario-titulo">
          <span className="apoio-etiqueta">VAMOS COMEÇAR?</span>
          <h2>Conte um pouco sobre você</h2>
          <p>
            Preencha o formulário para registrar sua solicitação de apoio.
          </p>
        </div>

        <form onSubmit={registrarSolicitacao}>
          <div className="apoio-campo">
            <label htmlFor="nome">Nome completo</label>
            <input
              id="nome"
              name="nome"
              type="text"
              placeholder="Digite seu nome"
              value={formulario.nome}
              onChange={atualizarCampo}
              required
            />
          </div>

          <div className="apoio-linha">
            <div className="apoio-campo">
              <label htmlFor="idade">Idade</label>
              <input
                id="idade"
                name="idade"
                type="number"
                min="14"
                max="21"
                placeholder="Sua idade"
                value={formulario.idade}
                onChange={atualizarCampo}
                required
              />
            </div>

            <div className="apoio-campo">
              <label htmlFor="cidade">Cidade</label>
              <input
                id="cidade"
                name="cidade"
                type="text"
                placeholder="Sua cidade"
                value={formulario.cidade}
                onChange={atualizarCampo}
                required
              />
            </div>
          </div>

          <div className="apoio-campo">
            <label htmlFor="contato">WhatsApp ou outro contato</label>
            <input
              id="contato"
              name="contato"
              type="text"
              placeholder="Informe um contato"
              value={formulario.contato}
              onChange={atualizarCampo}
              required
            />
          </div>

          <div className="apoio-campo">
            <label htmlFor="interesse">Em que você gostaria de receber apoio?</label>
            <select
              id="interesse"
              name="interesse"
              value={formulario.interesse}
              onChange={atualizarCampo}
              required
            >
              <option value="">Selecione uma opção</option>
              <option value="Educação">Educação e estudos</option>
              <option value="Oportunidades profissionais">Oportunidades profissionais</option>
              <option value="Orientação">Orientação e desenvolvimento</option>
              <option value="Conexões">Conexões e parcerias</option>
              <option value="Outro">Outro</option>
            </select>
          </div>

          <div className="apoio-campo">
            <label htmlFor="mensagem">Conte mais sobre o que você precisa</label>
            <textarea
              id="mensagem"
              name="mensagem"
              rows="5"
              placeholder="Escreva sua mensagem..."
              value={formulario.mensagem}
              onChange={atualizarCampo}
            />
          </div>

          <label className="apoio-consentimento">
            <input
              type="checkbox"
              name="consentimento"
              checked={formulario.consentimento}
              onChange={atualizarCampo}
              required
            />
            <span>
              Concordo com o envio dos dados informados para que a Youth Soul
              possa analisar minha solicitação de apoio.
            </span>
          </label>

          <button type="submit" disabled={enviando}>
            {enviando ? "Enviando..." : "Enviar solicitação →"}
          </button>

          {status && (
            <p
              className={erro ? "apoio-erro" : "apoio-sucesso"}
              role="status"
            >
              {status}
            </p>
          )}
        </form>
      </section>
    </main>
  );
}
