import React, { useState } from "react";
import { supabase } from "../services/supabase";

const perguntas = [
  {
    pergunta: "A Youth Soul realiza adoções diretamente?",
    resposta:
      "Não realizamos processos judiciais de adoção. Nosso projeto tem como proposta apoiar jovens em sua preparação para a vida adulta, promovendo oportunidades, orientação e parcerias. Os processos legais são conduzidos pelos órgãos competentes."
  },
  {
    pergunta: "Como meu negócio pode oferecer vagas de emprego ou estágio?",
    resposta:
      "Empresas interessadas podem entrar em contato pelo formulário e selecionar a opção de parceria. Assim, poderão apresentar suas propostas para avaliação da equipe do projeto."
  },
  {
    pergunta: "Para onde vai o valor das compras na Loja Alma Livre?",
    resposta:
      "A Loja Alma Livre faz parte da proposta do projeto Youth Soul. As informações sobre a destinação dos valores e o funcionamento das iniciativas serão apresentadas de forma transparente pela equipe."
  },
  {
    pergunta: "Preciso morar em São Paulo para participar?",
    resposta:
      "Não necessariamente! A participação em atividades presenciais ou on-line dependerá de cada iniciativa. Entre em contato para conhecer as possibilidades disponíveis."
  }
];

export default function Contato() {
  const [formulario, setFormulario] = useState({
    nome: "",
    email: "",
    telefone: "",
    motivo: "",
    mensagem: "",
    aceita_novidades: false
  });

  const [perguntaAberta, setPerguntaAberta] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [feedback, setFeedback] = useState({
    tipo: "",
    texto: ""
  });

  function atualizarCampo(event) {
    const { name, value, type, checked } = event.target;

    setFormulario((anterior) => ({
      ...anterior,
      [name]: type === "checkbox" ? checked : value
    }));
  }

  async function enviarMensagem(event) {
    event.preventDefault();
    setCarregando(true);
    setFeedback({ tipo: "", texto: "" });

    try {
      const { error } = await supabase
        .from("mensagens_contato")
        .insert([
          {
            nome: formulario.nome.trim(),
            email: formulario.email.trim(),
            telefone: formulario.telefone.trim(),
            motivo: formulario.motivo,
            mensagem: formulario.mensagem.trim(),
            aceita_novidades: formulario.aceita_novidades
          }
        ]);

      if (error) throw error;

      setFeedback({
        tipo: "sucesso",
        texto: "Sua mensagem foi registrada! Obrigado por entrar em contato com a Youth Soul. 💛"
      });

      setFormulario({
        nome: "",
        email: "",
        telefone: "",
        motivo: "",
        mensagem: "",
        aceita_novidades: false
      });
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);

      setFeedback({
        tipo: "erro",
        texto: "Não foi possível enviar sua mensagem. Verifique sua conexão e tente novamente."
      });
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="contact-page min-h-screen bg-background text-on-surface">
      {/* Faixa animada superior */}
      <div className="bg-sun-bright text-charcoal-ink overflow-hidden py-2 font-bold text-sm">
        <div className="animate-marquee whitespace-nowrap">
          <span className="mx-8">
            ✨ Estamos aqui para ouvir você • Faça parte da Youth Soul! 💛
          </span>
          <span className="mx-8">
            🌟 Juntos podemos construir novas oportunidades! 🌈
          </span>
          <span className="mx-8">
            ✨ Estamos aqui para ouvir você • Faça parte da Youth Soul! 💛
          </span>
          <span className="mx-8">
            🌟 Juntos podemos construir novas oportunidades! 🌈
          </span>
        </div>
      </div>

      <main className="relative overflow-hidden">
        {/* Elementos decorativos */}
        <div className="pointer-events-none absolute -left-20 top-20 h-72 w-72 rounded-full bg-soft-sky/30 blur-3xl" />
        <div className="pointer-events-none absolute -right-24 top-96 h-80 w-80 rounded-full bg-secondary-fixed/40 blur-3xl" />
        <div className="pointer-events-none absolute left-1/3 top-2/3 h-64 w-64 rounded-full bg-tertiary-fixed/30 blur-3xl" />

        {/* Apresentação */}
        <section className="relative mx-auto w-full max-w-7xl px-6 pb-12 pt-16 text-center lg:px-12">
          <div className="mb-6 inline-flex -rotate-1 items-center gap-2 rounded-full bg-tertiary-fixed px-4 py-2 text-sm font-extrabold text-on-tertiary-fixed shadow-sm transition-transform hover:rotate-0">
            ✨ Estamos prontos para ouvir você 💛
          </div>

          <h1 className="mx-auto mb-6 max-w-4xl text-4xl font-black tracking-tight text-on-surface md:text-6xl">
            Entre em Contato Conosco!{" "}
            <span className="inline-block transition-transform hover:rotate-12 hover:scale-125">
              💌
            </span>
          </h1>

          <p className="mx-auto mb-8 max-w-2xl text-lg leading-relaxed text-on-surface-variant">
            Seja para tirar dúvidas, propor uma parceria, participar de uma
            iniciativa ou compartilhar uma ideia — queremos ouvir você!
          </p>

          <div className="inline-flex flex-wrap items-center justify-center gap-2 rounded-full border-2 border-dashed border-outline-variant/70 bg-surface-container px-5 py-3 text-sm text-primary shadow-sm">
            <span className="material-symbols-outlined text-secondary">
              favorite
            </span>
            <span className="font-bold text-on-surface">
              Cada mensagem é importante para nós!
            </span>
            <span>💛</span>
          </div>
        </section>

        {/* Formulário e informações */}
        <section className="mx-auto mb-20 w-full max-w-7xl px-6 lg:px-12">
          <div className="grid grid-cols-1 items-start gap-8 lg:grid-cols-12">

            {/* Formulário */}
            <div className="relative overflow-hidden rounded-3xl border border-surface-container-high bg-surface-container-lowest p-6 shadow-xl md:p-10 lg:col-span-7">
              <div className="absolute -right-3 -top-3 flex h-16 w-16 rotate-12 items-center justify-center rounded-full bg-sun-bright/20 text-2xl">
                🧸
              </div>

              <div className="mb-8 flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary-fixed text-secondary shadow-sm">
                  <span className="material-symbols-outlined text-2xl">
                    mark_email_unread
                  </span>
                </div>

                <div>
                  <h2 className="text-xl font-extrabold text-on-surface">
                    Deixe seu recado! ✉️
                  </h2>
                  <p className="text-sm text-on-surface-variant">
                    Preencha os campos abaixo para falar com a gente.
                  </p>
                </div>
              </div>

              <form onSubmit={enviarMensagem} className="space-y-6">
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label htmlFor="nome" className="block text-sm font-extrabold">
                      Como prefere ser chamado? <span className="text-secondary">*</span>
                    </label>
                    <input
                      id="nome"
                      name="nome"
                      type="text"
                      required
                      maxLength={100}
                      value={formulario.nome}
                      onChange={atualizarCampo}
                      placeholder="Seu nome"
                      className="contact-input"
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="email" className="block text-sm font-extrabold">
                      Seu melhor e-mail <span className="text-secondary">*</span>
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      maxLength={150}
                      value={formulario.email}
                      onChange={atualizarCampo}
                      placeholder="nome@exemplo.com"
                      className="contact-input"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label htmlFor="telefone" className="block text-sm font-extrabold">
                      Telefone / WhatsApp <span className="text-secondary">*</span>
                    </label>
                    <input
                      id="telefone"
                      name="telefone"
                      type="tel"
                      required
                      maxLength={20}
                      value={formulario.telefone}
                      onChange={atualizarCampo}
                      placeholder="(11) 99999-9999"
                      className="contact-input"
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="motivo" className="block text-sm font-extrabold">
                      Motivo do contato <span className="text-secondary">*</span>
                    </label>
                    <select
                      id="motivo"
                      name="motivo"
                      required
                      value={formulario.motivo}
                      onChange={atualizarCampo}
                      className="contact-input"
                    >
                      <option value="">Selecione uma opção...</option>
                      <option value="voluntario">🙋 Quero ser voluntário(a)</option>
                      <option value="parceria">🤝 Quero propor parceria</option>
                      <option value="doacao">🎁 Dúvidas sobre doações e apoio</option>
                      <option value="recadinho">💌 Quero mandar um recadinho</option>
                      <option value="outro">✨ Outros assuntos</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="mensagem"
                    className="flex items-center justify-between text-sm font-extrabold"
                  >
                    <span>
                      Sua mensagem <span className="text-secondary">*</span>
                    </span>
                    <span className="text-xs font-semibold text-on-surface-variant">
                      {formulario.mensagem.length}/500
                    </span>
                  </label>

                  <textarea
                    id="mensagem"
                    name="mensagem"
                    required
                    maxLength={500}
                    rows={4}
                    value={formulario.mensagem}
                    onChange={atualizarCampo}
                    placeholder="Escreva sua mensagem aqui..."
                    className="contact-input resize-none"
                  />
                </div>

                <label className="flex cursor-pointer items-start gap-3 text-sm text-on-surface-variant">
                  <input
                    type="checkbox"
                    name="aceita_novidades"
                    checked={formulario.aceita_novidades}
                    onChange={atualizarCampo}
                    className="mt-1 h-4 w-4 accent-primary"
                  />
                  <span>
                    Aceito receber novidades e informações sobre as iniciativas
                    da Youth Soul por e-mail.
                  </span>
                </label>

                <p className="text-xs leading-relaxed text-on-surface-variant">
                  Seus dados serão utilizados para responder ao contato e,
                  somente se você autorizar, enviar novidades. Evite incluir
                  informações pessoais sensíveis na mensagem.
                </p>

                <button
                  type="submit"
                  disabled={carregando}
                  className="tactile-btn flex w-full items-center justify-center gap-3 rounded-full bg-bubblegum-bright px-6 py-4 text-lg font-extrabold text-white shadow-lg transition-all hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {carregando ? "Enviando mensagem... 💌" : "Enviar Mensagem com Amor"}
                  <span className="text-xl">✨</span>
                  <span className="material-symbols-outlined">arrow_forward</span>
                </button>
              </form>

              {feedback.texto && (
                <div
                  role="status"
                  className={`mt-6 flex items-center gap-4 rounded-2xl border-2 p-5 ${
                    feedback.tipo === "sucesso"
                      ? "border-primary bg-primary-fixed/40 text-on-primary-fixed"
                      : "border-red-300 bg-red-50 text-red-800"
                  }`}
                >
                  <span className="text-3xl">
                    {feedback.tipo === "sucesso" ? "🎉" : "⚠️"}
                  </span>
                  <p className="text-sm font-bold">{feedback.texto}</p>
                </div>
              )}
            </div>

            {/* Coluna lateral */}
            <div className="space-y-6 lg:col-span-5">
              <div className="space-y-5 rounded-3xl border border-surface-container-high bg-surface-container-lowest p-6 shadow-xl md:p-8">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-tertiary-fixed text-on-tertiary-fixed">
                    <span className="material-symbols-outlined text-2xl">
                      support_agent
                    </span>
                  </div>
                  <div>
                    <h2 className="text-xl font-extrabold">Fale Conosco Diretamente 💬</h2>
                    <p className="text-sm text-on-surface-variant">
                      Conheça nossos canais de contato.
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <a
                    href="mailto:ys@youthsoul.com.br"
                    className="contact-info-card group"
                  >
                    <div className="contact-info-icon bg-soft-sky/40 text-primary">
                      <span className="material-symbols-outlined">mail</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-on-surface-variant">E-mail do projeto</p>
                      <p className="truncate font-extrabold text-primary">
                        ys@youthsoul.com.br
                      </p>
                    </div>
                    <span className="material-symbols-outlined text-outline-variant">
                      arrow_outward
                    </span>
                  </a>

                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="contact-info-card group"
                  >
                    <div className="contact-info-icon bg-secondary-fixed text-secondary">
                      <span className="material-symbols-outlined">photo_camera</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-on-surface-variant">Rede social</p>
                      <p className="truncate font-extrabold text-secondary">
                        Instagram da Youth Soul
                      </p>
                    </div>
                    <span className="material-symbols-outlined text-outline-variant">
                      arrow_outward
                    </span>
                  </a>

                  <div className="contact-info-card">
                    <div className="contact-info-icon bg-primary-fixed text-primary">
                      <span className="material-symbols-outlined">location_on</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-on-surface-variant">Localização</p>
                      <p className="font-extrabold text-on-surface">
                        Informações de atendimento a definir
                      </p>
                      <p className="text-sm text-on-surface-variant">
                        Consulte a equipe sobre atividades presenciais.
                      </p>
                    </div>
                  </div>

                  <div className="contact-info-card">
                    <div className="contact-info-icon bg-tertiary-fixed text-tertiary">
                      <span className="material-symbols-outlined">schedule</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-on-surface-variant">Atendimento</p>
                      <p className="font-extrabold text-on-surface">
                        Entre em contato pelo formulário
                      </p>
                      <p className="text-sm text-on-surface-variant">
                        Os canais e horários serão divulgados pela equipe.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Cartão ilustrativo de localização */}
              <div className="space-y-4 rounded-3xl border border-surface-container-high bg-surface-container-lowest p-6 shadow-xl">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-secondary">
                      explore
                    </span>
                    <h3 className="font-extrabold">Onde estamos? 🌎</h3>
                  </div>
                  <span className="rounded-full bg-soft-sky/40 px-3 py-1 text-xs font-bold text-primary">
                    Youth Soul
                  </span>
                </div>

                <div className="contact-map flex h-48 items-end overflow-hidden rounded-2xl p-4 shadow-inner">
                  <div className="flex items-center gap-2 rounded-xl bg-white/90 px-4 py-3 shadow-md backdrop-blur-sm">
                    <span className="h-3 w-3 rounded-full bg-bubblegum-bright" />
                    <span className="text-sm font-extrabold text-charcoal-ink">
                      Localização a ser divulgada
                    </span>
                  </div>
                </div>

                <p className="text-center text-sm italic text-on-surface-variant">
                  "Estamos conectando pessoas e oportunidades!" 💛
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Perguntas frequentes */}
        <section className="mx-auto mb-20 w-full max-w-4xl px-6">
          <div className="mb-10 text-center">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-secondary-fixed px-4 py-2 text-xs font-extrabold text-secondary">
              Tire suas dúvidas
            </div>
            <h2 className="text-3xl font-black text-on-surface md:text-4xl">
              Perguntas Frequentes 💡
            </h2>
            <p className="mx-auto mt-3 max-w-lg text-on-surface-variant">
              Respostas para algumas curiosidades sobre nosso projeto.
            </p>
          </div>

          <div className="space-y-4">
            {perguntas.map((item, index) => (
              <div
                key={index}
                className="rounded-2xl border-2 border-surface-container bg-surface-container-lowest p-5 shadow-sm transition-all"
              >
                <button
                  type="button"
                  onClick={() =>
                    setPerguntaAberta(perguntaAberta === index ? null : index)
                  }
                  className="flex w-full items-center justify-between gap-4 text-left"
                  aria-expanded={perguntaAberta === index}
                >
                  <span className="flex items-center gap-3 font-extrabold text-on-surface">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary-fixed/50 text-sm text-primary">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    {item.pergunta}
                  </span>

                  <span
                    className={`material-symbols-outlined shrink-0 text-on-surface-variant transition-transform ${
                      perguntaAberta === index ? "rotate-180" : ""
                    }`}
                  >
                    expand_more
                  </span>
                </button>

                {perguntaAberta === index && (
                  <p className="mt-4 border-t border-surface-container-high pt-4 text-sm leading-relaxed text-on-surface-variant">
                    {item.resposta}
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Chamada final */}
        <section className="mx-auto mb-20 w-full max-w-5xl px-6">
          <div className="relative overflow-hidden rounded-3xl border border-white/60 bg-gradient-to-r from-secondary-fixed via-surface-container-lowest to-tertiary-fixed p-8 text-center shadow-xl md:p-12">
            <div className="pointer-events-none absolute -bottom-4 -left-4 h-20 w-20 rounded-full bg-sun-bright/30 blur-xl" />
            <div className="pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-soft-sky/30 blur-xl" />

            <span className="mb-3 inline-block text-3xl">💖</span>
            <h3 className="mb-3 text-2xl font-black tracking-tight text-charcoal-ink md:text-3xl">
              Ainda ficou com alguma dúvida?
            </h3>
            <p className="mx-auto mb-8 max-w-xl text-on-surface-variant">
              Envie sua mensagem pelo formulário e acompanhe as novidades da
              Youth Soul em nossos canais oficiais.
            </p>

            <a
              href="mailto:ys@youthsoul.com.br"
              className="tactile-btn inline-flex items-center gap-3 rounded-full bg-primary px-7 py-4 font-extrabold text-white shadow-lg transition-all hover:bg-secondary"
            >
              <span className="text-xl">📩</span>
              Enviar um e-mail
            </a>
          </div>
        </section>
      </main>
    </div>
  );
}
