
import React from 'react'
import { NavLink, Route, Routes, Link } from 'react-router-dom'
import ApoioAosJovens from './pages/ApoioAosJovens.jsx'
import Contato from './pages/Contato.jsx'

function Header() {
  return (
    <header className="site-header">
      <Link className="brand" to="/" aria-label="Youth Soul - início">
        <span className="brand-mark">YS</span>
        <span>Youth <b>Soul</b></span>
      </Link>

      <nav aria-label="Navegação principal">
        <NavLink to="/" end>Início</NavLink>
        <a href="/#quem-somos">Quem somos</a>
        <a href="/#iniciativas">Nossas iniciativas</a>
        <NavLink to="/apoio">Apoio aos jovens</NavLink>
        <a href="/#parceiros">Parceiros</a>
        <a href="/#loja">Loja Alma Livre</a>
        <NavLink to="/contato">Contato</NavLink>
      </nav>
    </header>
  )
}

function Home() {
  return (
    <main className="home-page">
      <section className="hero home-hero">
        <div className="hero-copy">
          <span className="eyebrow">
            ACOLHIMENTO • OPORTUNIDADES • CONEXÕES
          </span>

          <h1>Um espaço para descobrir novos caminhos.</h1>

          <p>
            A Youth Soul conecta jovens a informações, iniciativas e
            oportunidades para construir seus próximos passos com mais apoio.
          </p>

          <div className="hero-actions">
            <Link className="button button-primary" to="/apoio">
              Conheça o apoio
            </Link>

            <Link className="button button-light" to="/contato">
              Fale com a equipe
            </Link>
          </div>
        </div>

        <div className="hero-art" aria-hidden="true">
          <span>Seu futuro</span>
          <strong>
            começa<br />
            com novas<br />
            possibilidades.
          </strong>
          <i>✦</i>
        </div>
      </section>

      <section className="section intro-section" id="quem-somos">
        <span className="eyebrow">SOBRE A YOUTH SOUL</span>

        <h2>
          Jovens merecem ser ouvidos, respeitados e incentivados.
        </h2>

        <p>
          Somos um projeto de iniciativa social que reúne informações e
          caminhos de apoio para jovens. Nosso objetivo é aproximar pessoas,
          organizações e oportunidades.
        </p>
      </section>

      <section className="section feature-grid" id="iniciativas">
        <article className="feature-card">
          <span>01</span>
          <h3>Informação</h3>
          <p>
            Conteúdos para conhecer direitos, serviços e possibilidades.
          </p>
        </article>

        <article className="feature-card">
          <span>02</span>
          <h3>Oportunidades</h3>
          <p>
            Divulgação de cursos, experiências e caminhos para o primeiro emprego.
          </p>
        </article>

        <article className="feature-card">
          <span>03</span>
          <h3>Conexões</h3>
          <p>
            Um espaço para conhecer iniciativas e entrar em contato com a equipe.
          </p>
        </article>
      </section>

      <section className="cta-band" id="parceiros">
        <div>
          <span className="eyebrow">VAMOS CONVERSAR?</span>
          <h2>Todo caminho pode começar com uma conversa.</h2>
        </div>

        <Link className="button button-dark" to="/contato">
          Entre em contato
        </Link>
      </section>

      <div id="loja" className="store-note">
        Loja Alma Livre — espaço reservado para a próxima etapa do projeto.
      </div>
    </main>
  )
}

function Footer() {
  return (
    <footer className="footer">
      <div className="brand footer-brand">
        <span className="brand-mark">YS</span>
        <span>Youth <b>Soul</b></span>
      </div>

      <p>
        Informação, acolhimento e oportunidades para novos caminhos.
      </p>

      <div className="footer-links">
        <Link to="/apoio">Apoio aos jovens</Link>
        <Link to="/contato">Contato</Link>
      </div>

      <small>Projeto acadêmico demonstrativo • Youth Soul</small>
    </footer>
  )
}

export default function App() {
  return (
    <>
      <Header />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/apoio" element={<ApoioAosJovens />} />
        <Route path="/contato" element={<Contato />} />

        <Route
          path="*"
          element={
            <main className="section">
              <h1>Página não encontrada</h1>
              <Link to="/">Voltar ao início</Link>
            </main>
          }
        />
      </Routes>

      <Footer />
    </>
  )
}
